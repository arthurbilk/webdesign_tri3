const h1 = document.querySelector("h1")
const divAviso = document.createElement("div")

let cliques = 0
let nome

h1.onclick = function() {
    h1.classList.toggle("alt")
    cliques += 1
    h1.innerText = "REVISÃO " + cliques
    
    if (cliques == 1) {
        nome = prompt("Qual seu nome?")
    }

    if (cliques == 2) {
        divAviso.textContent = nome + " vai apagar o titulo em mais um clique"
        document.body.append(divAviso)
    }

    if (cliques >= 3) {
        h1.remove()
        divAviso.textContent = nome + " apagou o titulo no ultimo clique"
    }
}